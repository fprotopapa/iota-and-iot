#### Folder will be used to store signed credentials, as you follow along the tutorial.
