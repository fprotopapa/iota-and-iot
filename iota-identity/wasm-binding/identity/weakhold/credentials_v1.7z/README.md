#### Folder will be used to store weakhold objects, as you follow along the tutorial.
